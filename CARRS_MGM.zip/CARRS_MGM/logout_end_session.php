<?php
	$message = "Thanks for using C.A.R.R.S.!";
	echo "<script type='text/javascript'>alert('$message');</script>";
	echo '<script type="text/javascript">
		     window.location = "login.html"
		</script>';
	die();
?>