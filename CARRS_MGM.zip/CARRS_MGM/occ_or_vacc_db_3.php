<?php
// this gets the parameter from our Google Map html file
$o3 = $_REQUEST["o3"];

// this is the info for the server and connection credentials
$servername = "localhost:3306";
$username = "root";
$password = "root";
$databasename = "CEN3031_db";

// this creates a connection
$connection = new mysqli($servername, $username, $password, $databasename);
// this checks the connection for errors
if ($connection->connect_error) {
	die("Failed. " . $connection->connect_error);
} 

// this is how we will get the actual current time in php
// date_default_timezone_set("America/New_York");
// $currentTime = date("h:i:s");

// this is how we query the database with an example fixed time
$currentTime = "00:00:16";

// for this sql query, we may want the data to be automatic or user generated
$sql3 = "SELECT occOrVac, theTime FROM T3_real_time WHERE theTime = '$currentTime'";
$result3 = $connection->query($sql3);

if ($result3->num_rows > 0) {
	while($occResult3 = $result3->fetch_assoc()) {
		// we echo back the result from the query - will be either a '1' or '0'
		echo $occResult3["occOrVac"];
	}
} else {
	echo "Failed.";
}

?>

