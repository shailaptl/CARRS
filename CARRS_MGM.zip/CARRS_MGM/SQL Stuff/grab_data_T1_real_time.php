<?php
	// this is the info for the server and connection credentials
	$servername = "localhost:3306";
	$username = "root";
	$password = "root";
	$databasename = "CEN3031_db";

	// this creates a connection
	$connection = new mysqli($servername, $username, $password, $databasename);
	// this checks the connection for errors
	if ($connection->connect_error) {
		die("Failed. " . $connection->connect_error);
	} 

	// this is how we query the database
	// example time
	$currentTime = "00:00:17";

	$sql = "SELECT occOrVac, theTime FROM T1_real_time WHERE occOrVac = '1' AND theTime = '$currentTime'";
	$result = $connection->query($sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			if ($row == TRUE) {
				echo true;
			}
			else {
				echo false;
			}
		}
	} else {
		echo "Doesn't work.";
	}
	
	// this closes the connection
	$connection->close();	
?>